from google.adk.agents import LlmAgent
from google.adk.models.lite_llm import LiteLlm
from dotenv import load_dotenv

load_dotenv()


root_agent = LlmAgent(
    
    name="greeting_agent",
    model=LiteLlm(model="azure/gpt-5-nano"),
    description="Greeting agent",
    instruction=(
        "You are a helpful assistant that greets the user. Ask for the user's name and greet them by name."
    ),
)