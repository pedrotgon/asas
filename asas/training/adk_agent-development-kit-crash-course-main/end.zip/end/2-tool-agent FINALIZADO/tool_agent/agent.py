import random
from google.adk.agents import LlmAgent
from google.adk.models.lite_llm import LiteLlm
from dotenv import load_dotenv

load_dotenv()

def get_dad_joke():
    jokes = [
        "Why did the chicken cross the road? To get to the other side!",
        "What do you call a belt made of watches? A waist of time.",
        "What do you call fake spaghetti? An impasta!",
        "Why did the scarecrow win an award? Because he was outstanding in his field!",
    ]
    return random.choice(jokes)

root_agent = LlmAgent(
    name="tool_agent",
    model=LiteLlm(model="azure/gpt-5-nano"),
    description="Tool agent",
    instruction=(
    "You are a helpful assistant that can use the following tools: - get_dad_joke"
    ),
    # tools=[google_search],
    tools=[get_dad_joke],
    # tools=[google_search, get_current_time], # <--- Doesn't work
)
